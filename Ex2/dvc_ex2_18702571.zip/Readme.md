## Why do we need smoothing?
it removes noise from a data set (short-term)
it can help predict certain trends (long-term) 
## How does the window size affect the result?
The bigger the window size is, the more data points are getting lost. Therfore more data is hidden. With a smaller window size more data is taken in consideration, but trends cannot be seen. So we have to find a mix between a large and a small window size.